package com.example.mysql;

public class OgrModel {


    //veritabanı alan isimleri
    private String id,isim,numara;

   //sağ tık>generate>constructor ve sağ tık>generate>getter and setter
    public OgrModel(String id, String isim, String numara) {
        this.id = id;
        this.isim = isim;
        this.numara = numara;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getNumara() {
        return numara;
    }

    public void setNumara(String numara) {
        this.numara = numara;
    }
}
