package com.example.mysql;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class DetayActivity extends AppCompatActivity {
    Button buttonguncelle, buttonsil;
    EditText editTextad, editTextno;
    String id, adsoyad, numara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay);

        buttonguncelle = findViewById(R.id.btnguncelle);
        buttonsil = findViewById(R.id.btnsil);
        editTextad = findViewById(R.id.edtisimguncel);
        editTextno = findViewById(R.id.edtnoguncel);

            id = getIntent().getStringExtra("id");
            adsoyad = getIntent().getStringExtra("name");
            numara = getIntent().getStringExtra("no");
            editTextad.setText(adsoyad);
            editTextno.setText(numara);

        buttonsil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(DetayActivity.this);
                builder.setTitle("Uyarı!");
                builder.setMessage(editTextad.getText().toString()+" kaydı silinecektir..Onaylıyor musunuz?");
                builder.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        sil();
                    }
                });

                builder.setNegativeButton("Hayır", null); // tıklandığında işlem yok
                builder.show();
            }
        });

        buttonguncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guncelle();
            }
        });

    }

    private void guncelle() {
        String url="https://mobilapi.vercel.app/api/update.php?id=" + id;
        StringRequest istek=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
               Map<String,String> map=new HashMap<>();
               map.put("gelenisim",editTextad.getText().toString());
               map.put("gelenno",editTextno.getText().toString());
               return map;
            }
        };
        RequestQueue kuyruk=Volley.newRequestQueue(this);
        kuyruk.add(istek);
        Toast.makeText(this,"Güncellendi",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(DetayActivity.this,MainActivity.class));
    }

    private void sil() {
        String url = "https://mobilapi.vercel.app/api/deleteapi.php?id=" + id;
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                      }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                     }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                //return super.getParams(); getParams....
                Map<String, String> map = new HashMap<>();
                map.put("id", id);
                return map;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
        Toast.makeText(this, "Kayıt silindi.", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(DetayActivity.this, MainActivity.class));
    }


}