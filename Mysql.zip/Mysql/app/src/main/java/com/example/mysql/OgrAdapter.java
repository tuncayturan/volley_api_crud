package com.example.mysql;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class OgrAdapter extends RecyclerView.Adapter<OgrAdapter.ViewHolder> {
    Context context;
    ArrayList<OgrModel> modelArrayList;

    public OgrAdapter(Context context, ArrayList<OgrModel> modelArrayList) {
        this.context = context;
        this.modelArrayList =new ArrayList<>(modelArrayList);
    }

    @NonNull
    @Override
    public OgrAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.tekli_yapi,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        OgrModel model=modelArrayList.get(position);
        holder.txtno.setText(model.getNumara());
        holder.txtad.setText(model.getIsim());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //itemlere tıklanınca yapılacak işlemeler..
               //Toast.makeText(context, "ID: "+model.getId()+ " AdSoyad: "+model.getIsim()+" No: "+model.getNumara(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(), DetayActivity.class);
                intent.putExtra("id", model.getId());
                intent.putExtra("name", model.getIsim());
                intent.putExtra("no", model.getNumara());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtad, txtno;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtad = itemView.findViewById(R.id.textname);
            txtno = itemView.findViewById(R.id.textno);
        }
    }
    public void add(OgrModel ogrModel) {
        modelArrayList.add(ogrModel);
        notifyDataSetChanged();
    }
}
