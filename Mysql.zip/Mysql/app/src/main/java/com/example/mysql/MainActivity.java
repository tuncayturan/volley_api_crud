package com.example.mysql;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button buttonekle;
    EditText editTextad,editTextno;

    SwipeRefreshLayout swipeRefreshLayout;
    //Listeleme
    RecyclerView recyclerView;
    ArrayList<OgrModel> modelArrayList;
    OgrAdapter myadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String url="https://mobilapi.vercel.app/api/insert.php";
        buttonekle=findViewById(R.id.btnekle);
        editTextad=findViewById(R.id.edtisim);
        editTextno=findViewById(R.id.edtno);
        swipeRefreshLayout=findViewById(R.id.swiperefresh);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getData();
                Toast.makeText(MainActivity.this,"Sayfa yinelendi",Toast.LENGTH_SHORT).show();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        buttonekle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adsoyad=editTextad.getText().toString();
                String numara=editTextno.getText().toString();

                StringRequest request=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
                    @Nullable
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        //return super.getParams();
                        Map<String,String> map=new HashMap<>();
                        map.put("gelenisim",adsoyad);
                        map.put("gelenno",numara);
                        return map;
                    }
                };
                RequestQueue queue=Volley.newRequestQueue(getApplicationContext());
                queue.add(request);
                Toast.makeText(MainActivity.this, "Kayıt Başarılı", Toast.LENGTH_SHORT).show();

            }
        });

        recyclerView=findViewById(R.id.main_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        modelArrayList=new ArrayList<OgrModel>();
        getData();

    }

    private void getData() {
        myadapter=new OgrAdapter(this,modelArrayList);
        recyclerView.setAdapter(myadapter);
        myadapter.notifyDataSetChanged();
        String url="https://mobilapi.vercel.app/api/select.php";
        JsonArrayRequest request=new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject object = response.getJSONObject(i);
                        OgrModel ogrModel=new OgrModel(object.getString("id"),
                                object.getString("isim"),object.getString("numara"));
                        myadapter.add(ogrModel);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(request);

    }




}